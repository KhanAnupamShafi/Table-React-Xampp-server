import React from "react";

const Dashboard = () => {
  return (
    <div className="w-full text-center">
      <h2 className="text-3xl m-auto text-center font-semibold leading-tight">
        Dashboard Coming Soon
      </h2>
    </div>
  );
};

export default Dashboard;
