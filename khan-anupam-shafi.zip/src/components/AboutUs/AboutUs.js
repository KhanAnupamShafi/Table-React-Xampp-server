import React from "react";

const AboutUs = () => {
  return (
    <div>
      <h6>aaabout uuus</h6>
      <h6>aaabout uuus</h6>
      <h6>aaabout uuus</h6>
    </div>
  );
};

export default AboutUs;
